<?php include("config/db.php");?>
<?php
$msg="";

if(isset($_POST['submit'])){
  
     $name= $_POST['name'];
     $pass = $_POST['password'];
     $username= $_POST['username'];

   if($username != "" && $user != "" && $password !=""){
      $sql = "INSERT INTO tb_user(username, name, password) VALUES('$username','$name','$password')";
     
       $stmt = $pdo->prepare($sql);
       if($stmt ->execute()){
             header("location:../../login.html");
       } else {
             echo "Maaf, gagal menambahkan data";
       }
    } else {
          $error  = "Mohon isi semua data!";
    }
 
 }

   
       
 

 if(isset($_POST['sudah'])){
   header("location:../../login.html");
 }

   


?>