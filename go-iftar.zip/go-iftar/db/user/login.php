<?php

session_start();
include('../config.php');

if(isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $sql = "SELECT * FROM tb_user WHERE user_username = '$user' AND user_password = '$pass'";

    $query = $pdo->prepare($sql);
    $query->execute();

    if( $query->execute() ) {
        $result =  $query->fetchAll();
        $username = $result[0]['user_name'];

        $_SESSION['username'] = $username;
        $_SESSION['status'] = 'login';
        header('location: ../../');
    }
}

?>