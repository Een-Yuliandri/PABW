<?php


try {
    $pdo = new PDO('mysql:host=localhost;dbname=entech_iftaar_meal','entech_iftaar_meal','iftaar_meal');
    
} catch(PDOException $e) {
    echo $e->getMessage();
}



?>