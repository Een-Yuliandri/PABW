<?php

include('../config.php');

$id = $_GET['id'];

$sql = "DELETE FROM tb_meal WHERE meal_id = $id";

$query = $pdo->prepare($sql);

if($query->execute()) {
    header('location: ../../');
}


?>