<?php

include('../config.php');

if(isset($_POST['edit'])) {
    $id = $_POST['meal_id'];
    $name = $_POST['meal_name'];
    $desc = $_POST['meal_desc'];
    $cost = $_POST['meal_cost'];

    $sql = "UPDATE tb_meal SET meal_name='$name', meal_desc='$desc', meal_cost='$cost' WHERE meal_id=$id";
    $query = $pdo->prepare($sql);
    if($query->execute()) {
        header('location: ../../');
    }
}

?>