<?php

include('../config.php');

if(isset($_POST['submit'])) {
    $name = $_POST['meal_name'];
    $desc = $_POST['meal_desc'];
    $cost = $_POST['meal_cost'];

    $sql = "INSERT INTO tb_meal (meal_name,meal_desc,meal_cost) VALUES ('$name','$desc','$cost')";

    $query = $pdo->prepare($sql);

    if($query->execute()) {
        header('location: ../../');
    }
}

?>