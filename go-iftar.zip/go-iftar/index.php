<?php

  session_start();
  if($_SESSION['status'] != 'login') {
    header('location: login.html');
  }
  include_once('db/config.php');

  $result = $pdo->query("SELECT * FROM tb_meal ORDER BY meal_id");
  
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/style.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>GO-Iftar</title>
  </head>
  <body>

    <header>
      <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex">
          <a class="navbar-brand" href="#">GO-Iftar</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
            <ul class="navbar-nav ">
              <li class="nav-item active">
                <a class="nav-link" href="">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="">Menu</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Transaksi</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false">
                  <?=$_SESSION['username']?>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">Profil</a>
                  <a class="dropdown-item" href="#">Pengaturan</a>
                  <a class="dropdown-item" href="db/user/logout.php">Keluar</a>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </header>

    <main class="container-fluid">
      <div>
      <div class="container card">
        <div class="d-flex justify-content-between" style="padding: 5px">
          <h2>Tabel Menu</h2><span><a class="btn btn-outline-success" data-toggle="modal" data-target="#tambahModal">+ Tambah Data</a></span>
        </div>
        </span>
        <table class="table table-hover table-striped">
          <caption>List of users</caption>
          <thead>
            <tr>
              <th scope="col">No.</th>
              <th scope="col">Nama</th>
              <th scope="col">Deskripsi</th>
              <th scope="col">Harga</th>
              <th scope="col">Operasi</th>
            </tr>
          </thead>
          <tbody>
            <?php 

            $no=0;
            while($row = $result->fetch(PDO::FETCH_ASSOC)):
            $no++;
            ?>
            <tr>

              <th scope="row"><?=$no?></th>
              <td><?=$row['meal_name']?></td>
              <td><?=$row['meal_desc']?></td>
              <td><?=$row['meal_cost']?></td>
              <td>
                <a href="#" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editModal<?= $row['meal_id']; ?>">Ubah</a>
                <a href="db/kue/delete.php?id=<?= $row['meal_id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
              </td>


              <!-- Modal Edit -->
              <div class="modal fade" id="editModal<?= $row['meal_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Ubah Data Kue</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form action="db/kue/update.php" method="POST">
                        <input type="hidden" name="meal_id" value="<?=$row['meal_id']?>">
                        <div class="form-group">
                          <label for="exampleFormControlInput1">Nama</label>
                          <input type="text" name="meal_name" class="form-control" id="exampleFormControlInput1" placeholder="Nama" value="<?=$row['meal_name']?>"
                            required>
                          <br>
                          <label for="exampleFormControlInput1">Deskripsi</label>
                          <input type="text" name="meal_desc" class="form-control" id="exampleFormControlInput1"
                            placeholder="Deskripsi" value="<?=$row['meal_desc']?>" required>
                          <br>
                          <label for="exampleFormControlInput1">Harga</label>
                          <input type="text" name="meal_cost" class="form-control" id="exampleFormControlInput1" placeholder="Harga" value="<?=$row['meal_cost']?>"
                            required>
                        </div>
                        <br>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                          <input type="submit" name="edit" class="btn btn-primary" value="Simpan">
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <!-- END Modal Edit -->
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
      </div>
    </main>

    <footer class="d-flex justify-content-center">
      <p>Copyright by Go-Iftar &copy; 2020 All Rights Reserved</p>
    </footer>


    <!-- Modal Tambah -->
    <div class="modal fade" id="tambahModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Tambah Data Kue</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="db/kue/create.php" method="POST">
              <div class="form-group">
                <label for="exampleFormControlInput1">Nama</label>
                <input type="text" name="meal_name" class="form-control" id="exampleFormControlInput1" placeholder="Nama"
                  required>
                <br>
                <label for="exampleFormControlInput1">Deskripsi</label>
                <input type="text" name="meal_desc" class="form-control" id="exampleFormControlInput1"
                  placeholder="Deskripsi" required>
                <br>
                <label for="exampleFormControlInput1">Harga</label>
                <input type="text" name="meal_cost" class="form-control" id="exampleFormControlInput1" placeholder="Harga"
                  required>
              </div>
              <br>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                <input type="submit" name="submit" class="btn btn-primary" value="Simpan">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <!-- END Modal Tambah -->


    


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>